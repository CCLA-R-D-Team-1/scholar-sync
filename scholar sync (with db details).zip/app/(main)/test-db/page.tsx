'use client'

import { useEffect } from 'react'
import { supabase } from '@/lib/supabase'

export default function Test() {
  useEffect(() => {
    const testConnection = async () => {
      const { data, error } = await supabase.from('test').select('*')

      console.log('DATA:', data)
      console.log('ERROR:', error)
    }

    testConnection()
  }, [])

  return <div>Check console</div>
}