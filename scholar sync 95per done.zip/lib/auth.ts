import { supabase } from './supabase'

export interface AuthUser {
  id: string
  name: string
  email: string
  role: 'admin' | 'student'
}

export async function signUp(
  email: string,
  password: string,
  fullName: string,
): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    })

    if (error) return { user: null, error: error.message }
    if (!data.user) return { user: null, error: 'Registration failed' }

    // Upsert profile (trigger may have already created it)
    const { error: profileError } = await supabase.from('profiles').upsert(
      {
        id: data.user.id,
        email,
        full_name: fullName,
        role: 'student',
        is_active: true,
      },
      { onConflict: 'id', ignoreDuplicates: true },
    )

    if (profileError) console.error('Profile upsert error:', profileError)

    return {
      user: { id: data.user.id, name: fullName, email, role: 'student' },
      error: null,
    }
  } catch (err) {
    console.error('signUp error:', err)
    return { user: null, error: 'An unexpected error occurred' }
  }
}

export async function signIn(
  email: string,
  password: string,
): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })

    if (error) {
      console.error('signIn Supabase error:', error.message)
      return { user: null, error: 'Invalid email or password' }
    }
    if (!data.user) return { user: null, error: 'Login failed' }

    // Fetch profile — use the authenticated client (session is now active)
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('full_name, role')
      .eq('id', data.user.id)
      .single()

    if (profileError || !profile) {
      // Profile might not exist yet (e.g. email not confirmed, trigger didn't fire).
      // Create it now so login succeeds.
      console.warn('Profile not found after login, creating fallback profile')
      await supabase.from('profiles').upsert(
        {
          id: data.user.id,
          email: data.user.email!,
          full_name: data.user.user_metadata?.full_name || email,
          role: 'student',
          is_active: true,
        },
        { onConflict: 'id', ignoreDuplicates: false },
      )

      return {
        user: {
          id: data.user.id,
          name: data.user.user_metadata?.full_name || email,
          email: data.user.email!,
          role: 'student',
        },
        error: null,
      }
    }

    return {
      user: {
        id: data.user.id,
        name: profile.full_name || email,
        email: data.user.email!,
        role: profile.role as 'admin' | 'student',
      },
      error: null,
    }
  } catch (err) {
    console.error('signIn unexpected error:', err)
    return { user: null, error: 'An unexpected error occurred' }
  }
}

export async function signOut(): Promise<void> {
  await supabase.auth.signOut()
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  try {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser()

    if (error || !user) return null

    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('full_name, role')
      .eq('id', user.id)
      .single()

    if (profileError || !profile) {
      // Session is valid but profile is missing — return a minimal user
      // rather than null, so the session isn't treated as invalid
      return {
        id: user.id,
        name: user.user_metadata?.full_name || user.email!,
        email: user.email!,
        role: 'student',
      }
    }

    return {
      id: user.id,
      name: profile.full_name || user.email!,
      email: user.email!,
      role: profile.role as 'admin' | 'student',
    }
  } catch (err) {
    console.error('getCurrentUser error:', err)
    return null
  }
}

export async function getProfile(userId: string) {
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single()
  return data
}

export async function isAdmin(): Promise<boolean> {
  const user = await getCurrentUser()
  return user?.role === 'admin'
}
