import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

/**
 * Server-side Supabase client (no cookie handling).
 * Use for Server Components, Server Actions, and API routes.
 * This client reads environment variables safely server-side.
 */
export function createServerClient() {
  return createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  })
}

/**
 * Server Action: get the currently authenticated user's profile from the DB.
 * Requires the access token to be passed in (from cookies / headers).
 */
export async function getServerUser(accessToken: string) {
  const client = createServerClient()
  const { data: { user }, error } = await client.auth.getUser(accessToken)
  if (error || !user) return null

  const { data: profile } = await client
    .from('profiles')
    .select('id, email, full_name, role, avatar_url, is_active')
    .eq('id', user.id)
    .single()

  return profile
}
