/**
 * lib/actions.ts
 * Server-side actions for enrollment, event registration, profile updates,
 * and progress tracking. All functions validate auth before mutating data.
 */
'use server'

import { supabase } from './supabase'
import { getCurrentUser } from './auth'

// ── ENROLLMENT ───────────────────────────────────────────────────────────────

export async function enrollInCourseAction(courseId: string) {
  const user = await getCurrentUser()
  if (!user) return { data: null, error: 'Not authenticated' }

  // Check for existing enrollment
  const { data: existing } = await supabase
    .from('enrollments')
    .select('id')
    .eq('user_id', user.id)
    .eq('course_id', courseId)
    .single()

  if (existing) return { data: null, error: 'already_enrolled' }

  // Fetch course for price
  const { data: course } = await supabase
    .from('courses')
    .select('price, seats, enrolled_count, title')
    .eq('id', courseId)
    .single()

  if (!course) return { data: null, error: 'Course not found' }
  if (course.enrolled_count >= course.seats) return { data: null, error: 'Course is full' }

  const { data, error } = await supabase
    .from('enrollments')
    .insert({
      user_id: user.id,
      course_id: courseId,
      status: 'confirmed',
      payment_status: 'paid',
      amount_paid: course.price,
      progress: 0,
    })
    .select()
    .single()

  if (error) return { data: null, error: error.message }

  // Increment enrolled_count
  await supabase.rpc('increment_enrolled_count', { course_id: courseId })

  // Mock email notification
  await sendEnrollmentNotification(user.email, user.name, course.title)

  return { data, error: null }
}

export async function getUserEnrollmentsAction() {
  const user = await getCurrentUser()
  if (!user) return []

  const { data, error } = await supabase
    .from('enrollments')
    .select('*, courses(*)')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })

  if (error) return []
  return data || []
}

export async function checkEnrollmentAction(courseId: string): Promise<boolean> {
  const user = await getCurrentUser()
  if (!user) return false

  const { data } = await supabase
    .from('enrollments')
    .select('id')
    .eq('user_id', user.id)
    .eq('course_id', courseId)
    .single()

  return !!data
}

export async function updateProgressAction(enrollmentId: string, progress: number) {
  const user = await getCurrentUser()
  if (!user) return { error: 'Not authenticated' }

  const clampedProgress = Math.min(100, Math.max(0, progress))

  const { error } = await supabase
    .from('enrollments')
    .update({
      progress: clampedProgress,
      status: clampedProgress === 100 ? 'completed' : 'confirmed',
      updated_at: new Date().toISOString(),
    })
    .eq('id', enrollmentId)
    .eq('user_id', user.id) // Ensures users can only update their own

  return { error: error?.message || null }
}

// ── EVENT REGISTRATION ────────────────────────────────────────────────────────

export async function registerForEventAction(eventId: string) {
  const user = await getCurrentUser()
  if (!user) return { data: null, error: 'Not authenticated' }

  // Check for existing registration
  const { data: existing } = await supabase
    .from('event_registrations')
    .select('id')
    .eq('user_id', user.id)
    .eq('event_id', eventId)
    .single()

  if (existing) return { data: null, error: 'already_registered' }

  // Fetch event info
  const { data: event } = await supabase
    .from('events')
    .select('price, capacity, booked_count, title')
    .eq('id', eventId)
    .single()

  if (!event) return { data: null, error: 'Event not found' }
  if (event.booked_count >= event.capacity) return { data: null, error: 'Event is full' }

  const { data, error } = await supabase
    .from('event_registrations')
    .insert({
      user_id: user.id,
      event_id: eventId,
      quantity: 1,
      status: 'confirmed',
      payment_status: 'paid',
      amount_paid: event.price,
    })
    .select()
    .single()

  if (error) return { data: null, error: error.message }

  // Increment booked_count
  await supabase.rpc('increment_booked_count', { event_id: eventId, qty: 1 })

  // Mock email notification
  await sendEventNotification(user.email, user.name, event.title)

  return { data, error: null }
}

export async function getUserEventRegistrationsAction() {
  const user = await getCurrentUser()
  if (!user) return []

  const { data, error } = await supabase
    .from('event_registrations')
    .select('*, events(*)')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })

  if (error) return []
  return data || []
}

export async function checkEventRegistrationAction(eventId: string): Promise<boolean> {
  const user = await getCurrentUser()
  if (!user) return false

  const { data } = await supabase
    .from('event_registrations')
    .select('id')
    .eq('user_id', user.id)
    .eq('event_id', eventId)
    .single()

  return !!data
}

// ── PROFILE ───────────────────────────────────────────────────────────────────

export async function updateProfileAction(updates: {
  full_name?: string
  phone?: string
  university?: string
  year_of_study?: string
  major?: string
  avatar_url?: string
}) {
  const user = await getCurrentUser()
  if (!user) return { error: 'Not authenticated' }

  const { error } = await supabase
    .from('profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', user.id)

  return { error: error?.message || null }
}

export async function getFullProfileAction() {
  const user = await getCurrentUser()
  if (!user) return null

  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single()

  return data
}

// ── EMAIL NOTIFICATIONS (MOCK) ────────────────────────────────────────────────

async function sendEnrollmentNotification(email: string, name: string, courseTitle: string) {
  // In production: integrate with Resend, SendGrid, etc.
  // For now, we log the notification to console (simulated email)
  console.log(`
📧 EMAIL NOTIFICATION — Course Enrollment
To: ${email}
Subject: You've enrolled in "${courseTitle}"!

Hi ${name},

Congratulations! You have successfully enrolled in:
📚 ${courseTitle}

Log in to your dashboard to start learning.

Best regards,
Scholar Sync Team
  `)
  // Future: await resend.emails.send({ from: 'noreply@scholarsync.com', to: email, ... })
}

async function sendEventNotification(email: string, name: string, eventTitle: string) {
  console.log(`
📧 EMAIL NOTIFICATION — Event Registration
To: ${email}
Subject: You're registered for "${eventTitle}"!

Hi ${name},

You have successfully registered for:
🎉 ${eventTitle}

Check your dashboard for event details.

Best regards,
Scholar Sync Team
  `)
}
