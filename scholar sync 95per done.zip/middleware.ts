import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { createClient } from '@supabase/supabase-js'

// Routes that need authentication
const PROTECTED_ROUTES = ['/dashboard', '/profile', '/my-courses']
const ADMIN_ROUTES = ['/admin']

// NOTE: We do NOT gate /auth/login or /auth/register here.
// Cookie propagation at the edge is unreliable right after login,
// which causes redirect loops. The login/register pages handle
// their own "already logged in" redirects client-side.

async function getSessionFromRequest(
  request: NextRequest,
): Promise<{ userId: string | null; role: string | null }> {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

  let accessToken: string | null = null
  const allCookies = request.cookies.getAll()

  // Supabase may store the token as one cookie or split across chunks
  // Primary cookie: sb-<ref>-auth-token
  // Chunked: sb-<ref>-auth-token.0, sb-<ref>-auth-token.1, ...
  const chunkMap: Record<string, string> = {}

  for (const cookie of allCookies) {
    const name = cookie.name

    // Chunk pattern: ends with .0, .1, etc.
    const chunkMatch = name.match(/^(sb-.+-auth-token)\.(\d+)$/)
    if (chunkMatch) {
      chunkMap[chunkMatch[2]] = cookie.value
      continue
    }

    // Single cookie (non-chunked)
    if (name.startsWith('sb-') && name.endsWith('-auth-token')) {
      try {
        const decoded = decodeURIComponent(cookie.value)
        const parsed = JSON.parse(decoded)
        accessToken = parsed?.access_token ?? null
      } catch {
        // value might be a raw base64 chunk — skip
      }
    }
  }

  // Reassemble chunked token if we didn't get it from a single cookie
  if (!accessToken && Object.keys(chunkMap).length > 0) {
    const sorted = Object.keys(chunkMap)
      .sort((a, b) => Number(a) - Number(b))
      .map((k) => chunkMap[k])
      .join('')
    try {
      const decoded = decodeURIComponent(sorted)
      const parsed = JSON.parse(decoded)
      accessToken = parsed?.access_token ?? null
    } catch {
      // couldn't parse chunks — treat as unauthenticated
    }
  }

  if (!accessToken) return { userId: null, role: null }

  try {
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: { headers: { Authorization: `Bearer ${accessToken}` } },
    })

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser()

    if (error || !user) return { userId: null, role: null }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()

    return { userId: user.id, role: profile?.role ?? null }
  } catch {
    return { userId: null, role: null }
  }
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  const isAdminRoute = ADMIN_ROUTES.some((r) => pathname.startsWith(r))
  const isProtectedRoute = PROTECTED_ROUTES.some((r) => pathname.startsWith(r))

  // Skip middleware entirely for routes we don't protect
  if (!isAdminRoute && !isProtectedRoute) {
    return NextResponse.next()
  }

  const { userId, role } = await getSessionFromRequest(request)
  const isAuthenticated = !!userId

  // ── Admin routes ───────────────────────────────────────────────────────────
  if (isAdminRoute) {
    if (!isAuthenticated) {
      const url = new URL('/auth/login', request.url)
      url.searchParams.set('redirect', pathname)
      url.searchParams.set('message', 'Please sign in to access the admin panel')
      return NextResponse.redirect(url)
    }
    if (role !== 'admin') {
      // Authenticated but not an admin → student dashboard
      return NextResponse.redirect(new URL('/dashboard', request.url))
    }
  }

  // ── Protected student routes ───────────────────────────────────────────────
  if (isProtectedRoute && !isAuthenticated) {
    const url = new URL('/auth/login', request.url)
    url.searchParams.set('redirect', pathname)
    url.searchParams.set('message', 'Please sign in to continue')
    return NextResponse.redirect(url)
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    '/admin/:path*',
    '/dashboard/:path*',
    '/profile/:path*',
    '/my-courses/:path*',
  ],
}
