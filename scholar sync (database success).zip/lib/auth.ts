import { supabase } from './supabase'
import type { User } from '@supabase/supabase-js'

export interface AuthUser {
  id: string
  name: string
  email: string
  role: 'admin' | 'student'
}

export async function signUp(email: string, password: string, fullName: string): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: fullName }
      }
    })

    if (error) return { user: null, error: error.message }
    if (!data.user) return { user: null, error: 'Registration failed' }

    // Create profile
    const { error: profileError } = await supabase.from('profiles').insert({
      id: data.user.id,
      email,
      full_name: fullName,
      role: 'student',
      is_active: true,
    })

    if (profileError) console.error('Profile creation error:', profileError)

    return {
      user: { id: data.user.id, name: fullName, email, role: 'student' },
      error: null
    }
  } catch (err) {
    return { user: null, error: 'An unexpected error occurred' }
  }
}

export async function signIn(email: string, password: string): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) return { user: null, error: 'Invalid email or password' }
    if (!data.user) return { user: null, error: 'Login failed' }

    const profile = await getProfile(data.user.id)
    if (!profile) return { user: null, error: 'User profile not found' }

    return {
      user: {
        id: data.user.id,
        name: profile.full_name || email,
        email: data.user.email!,
        role: profile.role
      },
      error: null
    }
  } catch (err) {
    return { user: null, error: 'An unexpected error occurred' }
  }
}

export async function signOut(): Promise<void> {
  await supabase.auth.signOut()
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const profile = await getProfile(user.id)
  if (!profile) return null

  return {
    id: user.id,
    name: profile.full_name || user.email!,
    email: user.email!,
    role: profile.role
  }
}

export async function getProfile(userId: string) {
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single()
  return data
}

export async function isAdmin(): Promise<boolean> {
  const user = await getCurrentUser()
  return user?.role === 'admin'
}
