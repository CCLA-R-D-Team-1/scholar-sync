"use client"

import { useEffect, useState, use } from "react"
import Link from "next/link"
import { ArrowLeft, Calendar, MapPin, Users, Clock, Tag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { getEventBySlug } from "@/lib/data"
import { formatCurrency, formatDate } from "@/lib/utils"
import type { Event } from "@/types"

export default function EventDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params)
  const [event, setEvent] = useState<Event | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    getEventBySlug(slug).then((e) => { setEvent(e); setIsLoading(false) })
  }, [slug])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 py-12 space-y-4">
          {[...Array(3)].map((_, i) => <div key={i} className="h-32 bg-white rounded-2xl animate-pulse" />)}
        </div>
      </div>
    )
  }

  if (!event) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-700">Event not found</h2>
          <Button asChild className="mt-4"><Link href="/events">Browse Events</Link></Button>
        </div>
      </div>
    )
  }

  const spotsLeft = event.capacity - event.booked_count
  const isFull = spotsLeft <= 0

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 text-white">
        <div className="max-w-6xl mx-auto px-4 py-16">
          <Button variant="ghost" asChild className="text-purple-200 hover:text-white mb-6 -ml-2">
            <Link href="/events"><ArrowLeft className="h-4 w-4 mr-1" />All Events</Link>
          </Button>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <div className="flex flex-wrap gap-2 mb-4">
                <Badge className="bg-purple-700/50 text-purple-200">{event.category}</Badge>
                {event.is_featured && <Badge className="bg-yellow-400 text-yellow-900">⭐ Featured</Badge>}
              </div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">{event.title}</h1>
              <p className="text-purple-200 text-lg mb-6">{event.short_description || event.description.slice(0, 160)}</p>
              <div className="flex flex-wrap gap-6 text-sm text-purple-200">
                <span className="flex items-center gap-1.5"><Calendar className="h-4 w-4" />{formatDate(event.start_date)}</span>
                {event.start_time && <span className="flex items-center gap-1.5"><Clock className="h-4 w-4" />{event.start_time}{event.end_time && ` – ${event.end_time}`}</span>}
                <span className="flex items-center gap-1.5"><MapPin className="h-4 w-4" />{event.venue}</span>
                <span className="flex items-center gap-1.5"><Users className="h-4 w-4" />{event.booked_count} registered</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">About This Event</h2>
              <p className="text-gray-700 leading-relaxed whitespace-pre-line">{event.description}</p>
            </div>

            {event.agenda && event.agenda.length > 0 && (
              <div className="bg-white rounded-2xl p-8 shadow-sm">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Agenda</h2>
                <div className="space-y-4">
                  {event.agenda.map((item, i) => (
                    <div key={i} className="flex gap-4 items-start">
                      <div className="bg-purple-100 text-purple-800 text-xs font-bold px-3 py-1.5 rounded-lg whitespace-nowrap flex-shrink-0">{item.time}</div>
                      <div>
                        <p className="font-semibold text-gray-900">{item.title}</p>
                        {item.speaker && <p className="text-sm text-gray-500 mt-0.5">by {item.speaker}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {event.speakers && event.speakers.length > 0 && (
              <div className="bg-white rounded-2xl p-8 shadow-sm">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Speakers</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {event.speakers.map((speaker, i) => (
                    <div key={i} className="flex gap-4 items-start">
                      <div className="w-14 h-14 bg-gradient-to-br from-purple-400 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                        {speaker.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">{speaker.name}</p>
                        <p className="text-sm text-purple-600">{speaker.title}</p>
                        <p className="text-sm text-gray-500 mt-1 line-clamp-2">{speaker.bio}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {event.tags && event.tags.length > 0 && (
              <div className="bg-white rounded-2xl p-8 shadow-sm">
                <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2"><Tag className="h-5 w-5" />Tags</h2>
                <div className="flex flex-wrap gap-2">
                  {event.tags.map((tag) => (
                    <span key={tag} className="bg-purple-50 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">{tag}</span>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg p-6 sticky top-6">
              {event.image_url && <img src={event.image_url} alt={event.title} className="w-full h-44 object-cover rounded-xl mb-6" />}
              <div className="mb-4">
                <span className="text-3xl font-bold text-gray-900">{event.price === 0 ? "Free" : formatCurrency(event.price)}</span>
                {event.price > 0 && <p className="text-sm text-gray-500 mt-1">per person</p>}
              </div>
              <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white py-6 text-base font-semibold rounded-xl mb-4" disabled={isFull}>
                {isFull ? "Fully Booked" : "Register Now"}
              </Button>
              {!isFull && spotsLeft <= 20 && (
                <p className="text-center text-sm text-orange-600 font-medium mb-4">⚡ Only {spotsLeft} spots left!</p>
              )}
              <div className="space-y-3 text-sm text-gray-600 border-t pt-4">
                <div className="flex justify-between"><span>Date</span><span className="font-medium text-gray-900">{formatDate(event.start_date)}</span></div>
                {event.start_time && <div className="flex justify-between"><span>Time</span><span className="font-medium text-gray-900">{event.start_time}{event.end_time ? ` – ${event.end_time}` : ""}</span></div>}
                <div className="flex justify-between"><span>Venue</span><span className="font-medium text-gray-900 text-right max-w-[150px]">{event.venue}</span></div>
                <div className="flex justify-between"><span>Capacity</span><span className="font-medium text-gray-900">{event.capacity}</span></div>
                <div className="flex justify-between"><span>Available</span><span className={`font-medium ${isFull ? "text-red-600" : "text-green-600"}`}>{isFull ? "Full" : `${spotsLeft} spots`}</span></div>
                <div className="flex justify-between"><span>Organizer</span><span className="font-medium text-gray-900">{event.organizer}</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
